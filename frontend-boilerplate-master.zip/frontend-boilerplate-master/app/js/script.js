console.log("Load script.js");

// Instantiating the global app object
var app = {};
function hideFunction() {
    var x = document.getElementById("hide");
    if (x.style.display === "none") {
      x.style.display = "block";
    } else {
      x.style.display = "none";
    }
  }